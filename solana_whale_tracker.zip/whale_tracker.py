
import time
import requests
import json
import pandas as pd
from solana.rpc.api import Client
from alert import send_telegram_alert
import streamlit as st

# Load config
with open('config.json') as f:
    config = json.load(f)

client = Client("https://api.mainnet-beta.solana.com")
WHALE_ADDRESSES = config["whale_addresses"]

def get_transactions(address):
    try:
        response = client.get_confirmed_signature_for_address2(address, limit=10)
        return response.get("result", [])
    except Exception as e:
        print(f"Error fetching tx for {address}: {e}")
        return []

def check_whale_activity():
    st.title("Solana Whale Wallet Tracker")
    for addr in WHALE_ADDRESSES:
        txs = get_transactions(addr)
        if txs:
            st.subheader(f"Whale: {addr}")
            df = pd.DataFrame(txs)
            st.dataframe(df)
            if len(txs) > 0:
                send_telegram_alert(f"Whale Activity Detected on {addr}: {len(txs)} txs")
        else:
            st.write(f"No transactions found for {addr}")

if __name__ == "__main__":
    while True:
        check_whale_activity()
        time.sleep(300)  # 5 minutes
