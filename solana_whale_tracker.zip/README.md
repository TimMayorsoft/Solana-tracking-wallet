
# Solana Whale Wallet Tracker

## Features
- Tracks general whale addresses on Solana
- Sends Telegram alerts for transactions
- Streamlit dashboard to view activity
- Auto-runs every 5 minutes

## Setup
1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Configure `config.json`:
   - Add your Telegram bot token and chat ID
   - List whale wallet addresses to monitor

3. Run the dashboard:
   ```
   streamlit run whale_tracker.py
   ```

Ensure you create a Telegram bot using @BotFather and get your chat ID from @userinfobot.
